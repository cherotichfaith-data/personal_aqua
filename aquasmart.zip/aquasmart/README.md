# AquaSmart – Aquaculture Farm Intelligence Platform

AquaSmart is a real-time operational intelligence dashboard for modern aquaculture farms. Built with Next.js and Supabase, it empowers Farm Managers to monitor key performance indicators (KPIs), manage inventory, track feeding and mortality, analyze water quality, and generate compliance-ready reports—all from a single, secure interface.

---

## 🎯 Vision

Enable data-driven decision-making in aquaculture through:
- Real-time visibility into farm performance  
- Automated alerts for critical anomalies  
- Role-based access control and auditability  
- Regulatory compliance and reporting  
- Scalable architecture for single or multi-farm operations  

> Current Scope: Phase 1 focuses exclusively on the Farm Manager role, with core modules for KPIs, inventory, feeding, sampling, mortality, and water quality.

---

## 🧩 Core Features (v1.0)

### ✅ Dashboard & Core KPIs
- Real-time display of ABW, FCR, mortality, and more (≤5 min refresh)
- Drill-down by system, batch, and growth stage
- Configurable threshold alerts with alert history feed

### ✅ Inventory Management
- Fish stock tracking with mortality-adjusted population
- Feed inventory monitoring with reorder point alerts
- Full transaction log for stocking, consumption, and adjustments

### ✅ Feed Management
- Daily feeding logs with operator attribution
- Effective Feed Conversion Ratio (eFCR) calculation
- Consumption trend analysis

### ✅ Sampling & Mortality
- ABW sampling with statistical summary (avg, CV, std dev)
- Growth projections vs. target harvest weight
- Mortality logging with root cause classification and trend dashboards

### ✅ Water-Quality Module
- Manual logging of DO, pH, temperature, ammonia, depth
- Per-parameter threshold alerts (green/yellow/red status)
- Historical trends and compliance-ready export

### ✅ Reporting & Exports
- Pre-built PDF/CSV reports: performance, feed, mortality, water quality
- One-click CSV export from any data view
- Branded PDF templates with farm logo and commentary

### ✅ Security & Access Control
- Email/password authentication with email verification
- Role-Based Access Control (RBAC) – currently scoped to Farm Manager
- Row-Level Security (RLS) enforced at the database level
- Full audit trail of all data changes

---

## 🛠️ Tech Stack

| Layer | Technology |
|------|------------|
| Frontend | Next.js 14 (App Router), TypeScript, Tailwind CSS, Chart.js |
| Backend | Supabase (PostgreSQL, Auth, Realtime, Storage) |
| Auth | Supabase Auth (JWT, email/password) |
| Deployment | Vercel (frontend), Supabase Cloud (backend) |
| Testing | Vitest, Playwright, Supabase Test DB |

---

## 📁 Project Structure

aquasmart/
├── src/
│   ├── app/                 # Next.js App Router
│   │   ├── (auth)/          # Auth pages (login, register)
│   │   ├── dashboard/       # Main Farm Manager dashboard
│   │   └── layout.tsx       # Root layout with AuthProvider
│   ├── contexts/            # React contexts (AuthContext)
│   ├── lib/                 # Utilities, Supabase client, API services
│   ├── components/          # Reusable UI components
│   ├── types/               # TypeScript interfaces
│   └── styles/              # Global CSS & Tailwind config
├── public/                  # Static assets (logos, favicons)
├── .env.local.example       # Environment template
├── next.config.js
├── tailwind.config.ts
├── package.json
└── README.md
```

---

## 🚀 Getting Started

### Prerequisites
- Node.js ≥18.x
- npm or pnpm
- Supabase project (free tier supported)

### 1. Clone the repo
```bash
git clone https://github.com/your-org/aquasmart.git
cd aquasmart
```

### 2. Install dependencies
```bash
npm install
# or
pnpm install
```

### 3. Set up environment variables
Copy the example file and fill in your Supabase credentials:
```bash
cp .env.local.example .env.local
```

Then edit `.env.local`:
```env
NEXT_PUBLIC_SUPABASE_URL=your_supabase_project_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_anon_key
# SUPABASE_SERVICE_ROLE_KEY=your_service_role_key (optional, for admin tasks)
```

> 🔐 Never commit `.env.local` to version control.

### 4. Run the development server
```bash
npm run dev
# or
pnpm dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

---

## 🔒 Authentication & Roles

- Supported Role (v1.0): `farm_manager`
- User roles are stored in `auth.users.raw_user_meta_data.role`
- All data queries enforce Row-Level Security (RLS) based on:
  - User’s assigned farm(s)
  - Role permissions
- Farm Managers can only access data from farms they are assigned to

> 💡 During development, you can manually set a test user’s role via Supabase SQL:
> ```sql
> UPDATE auth.users 
> SET raw_user_meta_data = jsonb_set(
>   COALESCE(raw_user_meta_data, '{}'),
>   '{role}',
>   '"farm_manager"'
> )
> WHERE email = 'test@example.com';
> ```

---

## 📊 Data Model Highlights

Key tables (in Supabase):
- `farms` – Farm metadata (name, location, KPI targets)
- `systems` – Individual tanks/ponds within a farm
- `batches` – Fish cohorts with stocking date and species
- `feed_logs`, `mortality_logs`, `sampling_logs`, `water_quality_logs`
- `inventory_transactions` – Unified log for fish/feed movements
- `alerts` – Triggered threshold violations

All KPIs (ABW, FCR, mortality %) are computed via materialized views for performance.

---

## 🧪 Testing

- Unit tests: `npm run test`
- E2E tests: `npm run test:e2e`
- Linting: `npm run lint`

Ensure ≥80% coverage on core logic (KPI calculators, data transforms).

---

## 📅 Roadmap (Phase 2 / R2)

- Mobile offline app for field data entry
- Custom report builder (drag-and-drop)
- REST API for external integrations
- IoT sensor auto-sync (water quality, feeders)
- Predictive alerts using trend analysis
- Support for additional roles (System Operator, Data Analyst, Admin)

---

## 📄 License

Proprietary – © 2026 AquaSmart. All rights reserved.

---

## 🙋 Support

For issues or feature requests, contact the product team or open an internal ticket.

> Note: This project is currently in active development for Farm Manager workflows. Other roles and advanced analytics will be added in future phases.
```
